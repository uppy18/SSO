﻿using AzureADTest1.Utils;
using Microsoft.Identity.Client;
using Microsoft.IdentityModel.Logging;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Owin.Host.SystemWeb;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.Cookies;
using Microsoft.Owin.Security.Notifications;
using Microsoft.Owin.Security.OpenIdConnect;
using Owin;
using System;
using System.Configuration;
using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace AzureADTest1
{
    public partial class Startup
    {
        // Load configuration settings from PrivateSettings.config
        private static string appId = ConfigurationManager.AppSettings["ida:AppId"];
        private static string appSecret = ConfigurationManager.AppSettings["ida:AppSecret"];
        private static string redirectUri = ConfigurationManager.AppSettings["ida:RedirectUri"];
        private static string graphScopes = ConfigurationManager.AppSettings["ida:AppScopes"];


        public void ConfigureAuth(IAppBuilder app)
        {           

            app.SetDefaultSignInAsAuthenticationType(CookieAuthenticationDefaults.AuthenticationType);

            app.UseCookieAuthentication(new CookieAuthenticationOptions());

            app.UseOAuth2CodeRedeemer(
                new OAuth2CodeRedeemerOptions
                {
                    ClientId = appId,
                    ClientSecret = appSecret,
                    RedirectUri = redirectUri
                });

            app.UseOpenIdConnectAuthentication(
                new OpenIdConnectAuthenticationOptions
                {                   
                    ClientId = appId,
                    //IATA
                    Authority = "https://iataazurenonprodb2c.b2clogin.com/iataazurenonprodb2c.onmicrosoft.com/b2c_1a_signup_signin/v2.0",
                   
                    //Scope = $"openid email profile offline_access {graphScopes}",
                    ResponseType = OpenIdConnectResponseType.Code,
                    Scope =  $"{graphScopes}",
                    RedirectUri = redirectUri,
                    PostLogoutRedirectUri = redirectUri,
                    TokenValidationParameters = new TokenValidationParameters
                    {
                        // For demo purposes only, see below
                        //ValidateIssuer = false,

                        // In a real multi-tenant app, you would add logic to determine whether the
                        // issuer was from an authorized tenant
                        ValidateIssuer = true,
                        IssuerValidator = (issuer, token, tvp) =>
                        {
                            if (MyCustomTenantValidationAsync(issuer, token, tvp))
                            {
                                return issuer;
                            }
                            else
                            {
                                throw new SecurityTokenInvalidIssuerException("Invalid issuer");
                            }
                        }
                    },
                    Notifications = new OpenIdConnectAuthenticationNotifications
                    {
                        AuthenticationFailed = OnAuthenticationFailedAsync,
                        AuthorizationCodeReceived = OnAuthorizationCodeReceivedAsync
                    },
                    CookieManager = new SameSiteCookieManager(
                                     new SystemWebCookieManager())
                }
            );
        }

        private bool MyCustomTenantValidationAsync(string issuer, SecurityToken token, TokenValidationParameters tvp)
        {
            
            try
            {
                var myTenant = "11c12152-caa7-40c8-97bc-e480c95ebffd";
                var mySecurityKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(appSecret));
                var stsDiscoveryEndpoint = String.Format(CultureInfo.InvariantCulture, "https://iataazurenonprodb2c.b2clogin.com/iataazurenonprodb2c.onmicrosoft.com/b2c_1a_signup_signin/v2.0/.well-known/openid-configuration", myTenant);
                var configManager = new ConfigurationManager<OpenIdConnectConfiguration>(stsDiscoveryEndpoint, new OpenIdConnectConfigurationRetriever());
                var config = configManager.GetConfigurationAsync();

                //tring token = string.Empty;

                var tokenHandler = new JwtSecurityTokenHandler();

                var validationParameters = new TokenValidationParameters
                {
                    ValidAudience = appId,
                    ValidIssuer = issuer,
                    IssuerSigningKeys = config.Result.SigningKeys,
                    ValidateLifetime = false,
                    IssuerSigningKey = mySecurityKey
                };

                var validatedToken = (SecurityToken)new JwtSecurityToken();

                // Throws an Exception as the token is invalid (expired, invalid-formatted, etc.)  
                tokenHandler.ValidateToken(((JwtSecurityToken)token).RawData, validationParameters, out validatedToken);


                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }

        private static Task OnAuthenticationFailedAsync(AuthenticationFailedNotification<OpenIdConnectMessage,
            OpenIdConnectAuthenticationOptions> notification)
        {
            notification.HandleResponse();
            string redirect = $"/Home/Error?message={notification.Exception.Message}";
            if (notification.ProtocolMessage != null && !string.IsNullOrEmpty(notification.ProtocolMessage.ErrorDescription))
            {
                redirect += $"&debug={notification.ProtocolMessage.ErrorDescription}";
            }
            notification.Response.Redirect(redirect);
            return Task.FromResult(0);
        }

        private async Task OnAuthorizationCodeReceivedAsync(AuthorizationCodeReceivedNotification notification)
        {
            var idClient = ConfidentialClientApplicationBuilder.Create(appId)
                //.WithB2CAuthority("https://iataazurenonprodb2c.b2clogin.com/iataazurenonprodb2c.onmicrosoft.com/b2c_1a_signup_signin/v2.0")
                //.WithRedirectUri(redirectUri)
                //.WithTenantId("11c12152-caa7-40c8-97bc-e480c95ebffd")
                .WithClientSecret(appSecret)
                .Build();

            string message;
            string debug;

            try
            {
                string[] scopes= graphScopes.Split(' ');

                //string[] scopes = new[] { $"https://iataazurenonprodb2c.onmicrosoft.com/sis-dev/App.User"};               

                var result = await idClient.AcquireTokenByAuthorizationCode(
                    scopes, notification.Code).ExecuteAsync();

                message = "Access token retrieved.";
                debug = result.AccessToken;
            }
            catch (MsalException ex)
            {
                message = "AcquireTokenByAuthorizationCodeAsync threw an exception";
                debug = ex.Message;
            }

            var queryString = $"message={message}&debug={debug}";
            if (queryString.Length > 2048)
            {
                queryString = queryString.Substring(0, 2040) + "...";
            }

            notification.HandleResponse();
            notification.Response.Redirect($"/Home/Error?{queryString}");
        }
    }
}