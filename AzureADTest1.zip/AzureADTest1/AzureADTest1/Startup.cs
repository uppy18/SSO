﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartup(typeof(AzureADTest1.Startup))]

namespace AzureADTest1
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}

